package tacos.kitchen;

import tacos.Order;

public interface OrderReceiver {

  Order receiveOrder();

}